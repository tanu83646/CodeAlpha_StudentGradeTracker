import java.util.*;

public class StockTradingPlatform {
    static class Stock {
        String symbol;
        String company;
        double price;

        Stock(String symbol, String company, double price) {
            this.symbol = symbol;
            this.company = company;
            this.price = price;
        }
    }

    static class Holding {
        Stock stock;
        int quantity;

        Holding(Stock stock, int quantity) {
            this.stock = stock;
            this.quantity = quantity;
        }
    }

    static class User {
        String name;
        double cash;
        ArrayList<Holding> portfolio = new ArrayList<>();

        User(String name, double cash) {
            this.name = name;
            this.cash = cash;
        }

        void buy(Stock stock, int qty) {
            double cost = stock.price * qty;
            if (qty <= 0) {
                System.out.println("Quantity must be positive.");
            } else if (cash < cost) {
                System.out.println("Insufficient balance.");
            } else {
                cash -= cost;
                portfolio.add(new Holding(stock, qty));
                System.out.println("Bought " + qty + " shares of " + stock.symbol);
            }
        }

        void sell(Stock stock, int qty) {
            for (Holding h : portfolio) {
                if (h.stock.symbol.equals(stock.symbol) && h.quantity >= qty) {
                    h.quantity -= qty;
                    cash += stock.price * qty;
                    System.out.println("Sold " + qty + " shares of " + stock.symbol);
                    return;
                }
            }
            System.out.println("Not enough shares to sell.");
        }

        void showPortfolio() {
            System.out.println("\n========== PORTFOLIO ==========");
            for (Holding h : portfolio) {
                if (h.quantity > 0) {
                    System.out.printf("%s - %d shares - Value: %.2f%n",
                            h.stock.symbol, h.quantity, h.quantity * h.stock.price);
                }
            }
            System.out.printf("Available Cash: %.2f%n", cash);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Stock> market = new ArrayList<>();
        market.add(new Stock("TCS", "Tata Consultancy Services", 3800));
        market.add(new Stock("INFY", "Infosys", 1800));
        market.add(new Stock("RELI", "Reliance Industries", 2900));

        System.out.print("Enter user name: ");
        User user = new User(sc.nextLine(), 100000);

        while (true) {
            System.out.println("\n===== STOCK TRADING PLATFORM =====");
            System.out.println("1. View Market");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.println("\nSymbol\tCompany\t\t\tPrice");
                for (Stock s : market)
                    System.out.printf("%s\t%-25s %.2f%n", s.symbol, s.company, s.price);

            } else if (choice == 2 || choice == 3) {
                System.out.print("Enter stock symbol: ");
                String symbol = sc.next().toUpperCase();
                Stock selected = null;
                for (Stock s : market)
                    if (s.symbol.equals(symbol)) selected = s;

                if (selected == null) {
                    System.out.println("Stock not found.");
                } else {
                    System.out.print("Enter quantity: ");
                    int qty = sc.nextInt();
                    if (choice == 2) user.buy(selected, qty);
                    else user.sell(selected, qty);
                }

            } else if (choice == 4) {
                user.showPortfolio();

            } else if (choice == 5) {
                System.out.println("Thank you for using the platform.");
                break;

            } else {
                System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }
}