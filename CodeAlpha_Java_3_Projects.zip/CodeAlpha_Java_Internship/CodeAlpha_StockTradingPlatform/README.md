# CodeAlpha Stock Trading Platform

A Java console-based simulation of a stock trading environment.

## Features
- Market data display
- Buy and sell operations
- User cash balance
- Portfolio management
- OOP classes for stocks, holdings and users

## Run
```bash
javac StockTradingPlatform.java
java StockTradingPlatform
```
