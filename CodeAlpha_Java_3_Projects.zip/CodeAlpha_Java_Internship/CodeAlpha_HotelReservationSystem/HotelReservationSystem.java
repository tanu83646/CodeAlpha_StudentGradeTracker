import java.io.*;
import java.util.*;

public class HotelReservationSystem {
    static class Room {
        int number;
        String category;
        double price;
        boolean booked;

        Room(int number, String category, double price) {
            this.number = number;
            this.category = category;
            this.price = price;
            this.booked = false;
        }
    }

    static ArrayList<Room> rooms = new ArrayList<>();
    static final String FILE = "bookings.txt";

    static void showRooms() {
        System.out.println("\nRoom\tCategory\tPrice\tStatus");
        for (Room r : rooms) {
            System.out.printf("%d\t%-10s\t%.2f\t%s%n",
                    r.number, r.category, r.price,
                    r.booked ? "Booked" : "Available");
        }
    }

    static void saveBooking(Room room, String guest, int nights) {
        try (FileWriter fw = new FileWriter(FILE, true)) {
            fw.write("Guest: " + guest + ", Room: " + room.number +
                    ", Category: " + room.category + ", Nights: " + nights +
                    ", Total: " + (room.price * nights) + System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Could not save booking.");
        }
    }

    static void bookRoom(Scanner sc) {
        showRooms();
        System.out.print("\nEnter room number: ");
        int number = sc.nextInt();
        sc.nextLine();

        Room selected = null;
        for (Room r : rooms)
            if (r.number == number) selected = r;

        if (selected == null || selected.booked) {
            System.out.println("Room unavailable.");
            return;
        }

        System.out.print("Guest name: ");
        String guest = sc.nextLine();
        System.out.print("Number of nights: ");
        int nights = sc.nextInt();

        if (nights <= 0) {
            System.out.println("Invalid number of nights.");
            return;
        }

        selected.booked = true;
        double total = selected.price * nights;
        saveBooking(selected, guest, nights);

        System.out.printf("Booking confirmed. Total payment: %.2f%n", total);
    }

    static void cancelRoom(Scanner sc) {
        System.out.print("Enter room number to cancel: ");
        int number = sc.nextInt();

        for (Room r : rooms) {
            if (r.number == number && r.booked) {
                r.booked = false;
                System.out.println("Reservation cancelled.");
                return;
            }
        }
        System.out.println("No active booking found.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        rooms.add(new Room(101, "Standard", 2000));
        rooms.add(new Room(102, "Standard", 2000));
        rooms.add(new Room(201, "Deluxe", 3500));
        rooms.add(new Room(301, "Suite", 5500));

        while (true) {
            System.out.println("\n===== HOTEL RESERVATION SYSTEM =====");
            System.out.println("1. Search/View Rooms");
            System.out.println("2. Book Room");
            System.out.println("3. Cancel Reservation");
            System.out.println("4. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> showRooms();
                case 2 -> bookRoom(sc);
                case 3 -> cancelRoom(sc);
                case 4 -> {
                    System.out.println("Thank you.");
                    sc.close();
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}