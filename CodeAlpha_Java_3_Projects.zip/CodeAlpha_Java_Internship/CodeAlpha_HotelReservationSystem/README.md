# CodeAlpha Hotel Reservation System

A Java console application for searching, booking and cancelling hotel rooms.

## Features
- Room categories: Standard, Deluxe and Suite
- Room availability
- Booking and cancellation
- Payment/total calculation simulation
- OOP design using Room class
- File I/O: booking details are saved to `bookings.txt`

## Run
```bash
javac HotelReservationSystem.java
java HotelReservationSystem
```
